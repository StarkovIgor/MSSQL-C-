﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace STO_DB
{
    public partial class OrderForm : Form
    {
        private SqlConnection sqlConnection;
        public OrderForm()
        {
            InitializeComponent();
        }

        private void butAddOrder_Click(object sender, EventArgs e)
        {
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO Orders (Receiver, Master, Date) VALUES (@Receiver, @Master, @Date)", sqlConnection);
            sqlCommand.Parameters.AddWithValue("Receiver", textBox1.Text);
            sqlCommand.Parameters.AddWithValue("Master", textBox5.Text);
            sqlCommand.Parameters.AddWithValue("Date", dateTimePicker2.Value);
            sqlCommand.ExecuteNonQuery();
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["STO_DB"].ConnectionString);
            sqlConnection.Open();
        }
    }
}
